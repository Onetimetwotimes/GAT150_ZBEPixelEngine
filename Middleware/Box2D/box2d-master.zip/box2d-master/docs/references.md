# References
- [Erin Catto's Publications](https://box2d.org/publications/)
- Collision Detection in Interactive 3D Environments, Gino van den Bergen, 2004
- Real-Time Collision Detection, Christer Ericson, 2005
